
from fib import fibonaci
print(fibonaci(20))